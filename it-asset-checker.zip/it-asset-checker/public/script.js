async function updateStatus() {
    const location = document.getElementById('location').value;
    const internetStatus = document.getElementById('internet').value;
    const printersStatus = document.getElementById('printers').value;
    const serversStatus = document.getElementById('servers').value;
    const conferenceStatus = document.getElementById('conference').value;

    const status = {
        internet: internetStatus,
        printers: printersStatus,
        servers: serversStatus,
        conference: conferenceStatus
    };

    try {
        const response = await fetch('http://localhost:4000/update-status', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ location, status })
        });

        const result = await response.json();
        document.getElementById('status-output').innerText = result.message;
        loadDashboard();
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('status-output').innerText = 'Failed to update status';
    }
}

async function loadDashboard() {
    try {
        const response = await fetch('http://localhost:4000/status');
        const data = await response.json();
        const dashboard = document.getElementById('dashboard');
        dashboard.innerHTML = '';

        data.forEach(record => {
            const recordDiv = document.createElement('div');
            recordDiv.innerText = `Location: ${record.location}, Date: ${record.date}, Internet: ${record.status.internet}, Printers: ${record.status.printers}, Servers: ${record.status.servers}, Conference: ${record.status.conference}`;
            dashboard.appendChild(recordDiv);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

document.addEventListener('DOMContentLoaded', loadDashboard);
