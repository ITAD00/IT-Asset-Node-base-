const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 4000;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

let assetsStatus = [];

app.post('/update-status', (req, res) => {
    const { location, status } = req.body;
    const date = new Date().toISOString().split('T')[0];

    const existingRecordIndex = assetsStatus.findIndex(record => record.date === date && record.location === location);
    if (existingRecordIndex >= 0) {
        assetsStatus[existingRecordIndex].status = status;
    } else {
        assetsStatus.push({ date, location, status });
    }

    res.send({ message: 'Status updated successfully' });
});

app.get('/status', (req, res) => {
    res.send(assetsStatus);
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
